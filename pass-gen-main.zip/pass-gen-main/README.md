# Password Generator
A Simple Password Generator with Python [Eel](https://github.com/ChrisKnott/Eel).
![Image](https://i.imgur.com/aU3GynF.png)
